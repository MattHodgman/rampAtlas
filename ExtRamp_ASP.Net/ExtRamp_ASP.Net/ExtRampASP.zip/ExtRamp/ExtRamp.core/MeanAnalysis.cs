﻿namespace ExtRamp.core
{
    public enum MeanAnalysis
    {
        Harmonic,
        Geometric,
        Arithmetic,
        Median
    }
}
